import pandas as pd
import numpy as np
import matplotlib.pyplot as plt

from sklearn.linear_model import LinearRegression
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score

# ==========================
# LOAD DATASET
# ==========================
data = pd.read_csv("../dataset/sales_data.csv")

# Create month number feature
data["Month"] = range(1, len(data) + 1)

X = data[["Month"]]
y = data["Sales"]

# ==========================
# TRAIN MODEL
# ==========================
model = LinearRegression()
model.fit(X, y)

# Predictions
predictions = model.predict(X)

# ==========================
# EVALUATION
# ==========================
mae = mean_absolute_error(y, predictions)
rmse = np.sqrt(mean_squared_error(y, predictions))
r2 = r2_score(y, predictions)

print("\n========== SALES FORECASTING REPORT ==========")
print(f"Mean Absolute Error (MAE): {mae:.2f}")
print(f"Root Mean Squared Error (RMSE): {rmse:.2f}")
print(f"R2 Score: {r2:.4f}")

# ==========================
# FUTURE FORECAST (NEXT 6 MONTHS)
# ==========================
future_months = np.array([[25], [26], [27], [28], [29], [30]])
future_sales = model.predict(future_months)

print("\nFuture Sales Forecast:")
for month, sale in zip(range(25, 31), future_sales):
    print(f"Month {month}: {sale:.2f}")

# ==========================
# GRAPH 1 - SALES TREND
# ==========================
plt.figure(figsize=(8, 5))
plt.plot(data["Month"], data["Sales"], marker="o")
plt.title("Monthly Sales Trend")
plt.xlabel("Month")
plt.ylabel("Sales")
plt.grid(True)

plt.savefig("../graphs/sales_trend.png")
plt.show()
plt.close()

# ==========================
# GRAPH 2 - ACTUAL VS PREDICTED
# ==========================
plt.figure(figsize=(8, 5))
plt.plot(data["Month"], y, label="Actual Sales")
plt.plot(data["Month"], predictions, label="Predicted Sales")
plt.title("Actual vs Predicted Sales")
plt.xlabel("Month")
plt.ylabel("Sales")
plt.legend()
plt.grid(True)

plt.savefig("../graphs/prediction_vs_actual.png")
plt.show()
plt.close()

# ==========================
# GRAPH 3 - FUTURE FORECAST
# ==========================
plt.figure(figsize=(8, 5))
plt.plot(
    range(25, 31),
    future_sales,
    marker="o"
)
plt.title("Future Sales Forecast (Next 6 Months)")
plt.xlabel("Future Month")
plt.ylabel("Predicted Sales")
plt.grid(True)

plt.savefig("../graphs/future_forecast.png")
plt.show()
plt.close()

print("\nGraphs saved successfully!")
print("1. sales_trend.png")
print("2. prediction_vs_actual.png")
print("3. future_forecast.png")