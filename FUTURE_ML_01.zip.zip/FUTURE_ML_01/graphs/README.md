# Sales & Demand Forecasting for Businesses

## Project Overview

This project predicts future sales trends using Machine Learning techniques. Historical sales data was analyzed and a Linear Regression model was trained to forecast sales performance.

## Objectives

* Analyze historical sales data
* Build a forecasting model
* Visualize sales trends
* Compare actual and predicted sales

## Technologies Used

* Python
* Pandas
* NumPy
* Matplotlib
* Scikit-learn
* VS Code

## Dataset

The dataset contains monthly sales records from 2023 to 2024.

## Methodology

1. Data Collection
2. Data Preprocessing
3. Feature Engineering
4. Model Training using Linear Regression
5. Performance Evaluation
6. Data Visualization

## Results

* Generated Sales Trend Graph
* Generated Actual vs Predicted Sales Graph
* Evaluated model performance using MAE and R² Score

## Conclusion

The Linear Regression model successfully identified the sales growth trend and provided reliable sales forecasts based on historical data.

## Author

Chodagiri.Vennala
